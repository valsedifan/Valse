/**
 * Script de personnalisation des champs de contact dans la page de profil
 * Emplacement : toutes les pages
 * @author 'Christa Lostmindy
 */
const LISTE_CHAMPS_CONTACT = [ /* Liste des champs de contact à modifier, suivez l'exemple et faites attention à l'emplacement des virgules et crochets */
  	{
            selector : '#i_icon_pm',
            replacementCode : '<i class="cp cp-envelope"></i>',
            title : 'envoyer un message privé'
        },
        {
            selector : '#field_id-10 .field_uneditable img',
            replacementCode : '<i class="cp cp-id-card"></i>',
            title : 'accéder à la présentation'
        },
        {
            selector : '#field_id15 .field_uneditable img',
            replacementCode : '<i class="cp cp-bookmark"></i>',
            title : 'accéder au carnet de bord'
        },
        {
            selector : '#field_id14 .field_uneditable img',
            replacementCode : '<i class="cp cp-instagram"></i>',
            title : "accéder à l'instagram"
        },
        {
            selector : '#field_id20 .field_uneditable img',
            replacementCode : '<i class="cp cp-music-note"></i>',
            title : 'accéder à la playlist'
        },
          {
            selector : '#field_id21 .field_uneditable img',
            replacementCode : '<i class="cp cp-image"></i>',
            title : 'accéder au moodboard'
        }
];

function customChampContact(liste) {
    liste.forEach(replacement => {
        const targetElement = document.querySelector(replacement.selector);
        if (targetElement) {
            if(replacement.title?.trim().length) targetElement.closest('a')?.setAttribute('title', replacement.title);
            if(replacement.replacementCode?.trim().length) targetElement.parentElement.innerHTML = replacement.replacementCode;
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    customChampContact(LISTE_CHAMPS_CONTACT);
});
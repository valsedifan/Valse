document.addEventListener('DOMContentLoaded', () => {
  const rankColors = {
    ten: getComputedStyle(document.documentElement).getPropertyValue('--ten').trim(),
    's-class': getComputedStyle(document.documentElement).getPropertyValue('--s-class').trim(),
    'a-class': getComputedStyle(document.documentElement).getPropertyValue('--a-class').trim(),
    'b-class': getComputedStyle(document.documentElement).getPropertyValue('--b-class').trim(),
    'c-class': getComputedStyle(document.documentElement).getPropertyValue('--c-class').trim(),
    't-class': getComputedStyle(document.documentElement).getPropertyValue('--t-class').trim(),
    'v-class': getComputedStyle(document.documentElement).getPropertyValue('--v-class').trim(),
    'x-class': getComputedStyle(document.documentElement).getPropertyValue('--x-class').trim(),
    'h-class': getComputedStyle(document.documentElement).getPropertyValue('--h-class').trim(),
  };

  function saveColorsToStorage() {
    let users = JSON.parse(localStorage.getItem('userColors')) || {};

    document.querySelectorAll('.post_row').forEach((postRow) => {
      const pseudoSpan = postRow.querySelector('.post_pseudo span');
      const username = pseudoSpan ? pseudoSpan.textContent.trim() : null;
      const groupColor = pseudoSpan ? getComputedStyle(pseudoSpan).color : null;
      const rankField = postRow.querySelector('.field-rank .field_content');
      const rankText = rankField ? rankField.textContent.trim().toLowerCase() : null;
      const rankColor = rankText ? rankColors[rankText] : null;

      if (username) {
        if (!users[username]) {
          users[username] = {};
        }
        if (groupColor) {
          users[username].groupecolor = groupColor;
        }
        if (rankColor) {
          users[username].rankcolor = rankColor;
        }
      }
    });

    localStorage.setItem('userColors', JSON.stringify(users));
  }

  function loadColorsFromStorage() {
    const users = JSON.parse(localStorage.getItem('userColors')) || {};

    document.querySelectorAll('.post_row').forEach((postRow) => {
      const pseudoSpan = postRow.querySelector('.post_pseudo span');
      const username = pseudoSpan ? pseudoSpan.textContent.trim() : null;
      const user = users[username];

      if (user) {
        if (user.groupecolor) {
          postRow.style.setProperty('--groupecolor', user.groupecolor);
        }
        if (user.rankcolor) {
          postRow.style.setProperty('--rankcolor', user.rankcolor);
        }
      }
    });
  }

  function applyCarnetDebordColors() {
    const carnetDebord = document.querySelector('.carnetdebord');
    if (carnetDebord) {
      const couleur1 = getComputedStyle(carnetDebord).getPropertyValue('--couleur1').trim();
      const couleur2 = getComputedStyle(carnetDebord).getPropertyValue('--couleur2').trim();
      const couleur3 = getComputedStyle(carnetDebord).getPropertyValue('--couleur3').trim();

      document.querySelectorAll('.post_row').forEach(postRow => {
        postRow.style.setProperty('--couleur1', couleur1);
        postRow.style.setProperty('--couleur2', couleur2);
        postRow.style.setProperty('--couleur3', couleur3);
      });
    }
  }

  function processPostRows() {
    loadColorsFromStorage();
    applyCarnetDebordColors();
  }

  processPostRows();

  const observer = new MutationObserver(() => {
    processPostRows();
    saveColorsToStorage(); 
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });

  const container = document.querySelector('.container#wombat');
  if (container) {
    const pageTitleSpan = container.querySelector('h1.page-title span');
    if (pageTitleSpan) {
      const groupColor = getComputedStyle(pageTitleSpan).color;
      container.style.setProperty('--groupecolor', groupColor);
    }

    const rankField = container.querySelector('#field_id1 .field_uneditable');
    if (rankField) {
      const rankText = rankField.textContent.trim().toLowerCase();
      const rankColor = rankColors[rankText];

      if (rankColor) {
        container.style.setProperty('--rankcolor', rankColor);
      }
    }
  }

  document.querySelectorAll('.userlist_profil').forEach(profil => {
    const pseudoSpan = profil.querySelector('.userlist_pseudo span[style]');
    if (pseudoSpan) {
      const username = pseudoSpan.textContent.trim();
      const users = JSON.parse(localStorage.getItem('userColors')) || {};
      const user = users[username];

      if (user && user.groupecolor) {
        profil.style.setProperty('--groupecolor', user.groupecolor);
      } else {
        const computedColor = window.getComputedStyle(pseudoSpan).color;
        profil.style.setProperty('--groupecolor', computedColor);
      }
    }
  });

  if (!localStorage.getItem('userColors')) {
    saveColorsToStorage();
  }
});
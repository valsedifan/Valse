document.addEventListener('DOMContentLoaded', function() {
    // Define your items with their associated icons and rank colors
    const itemsWithIcons = {
        "Détection de présence": { icon: "game-icon-eye-target", rankClass: "c-class" },
        "Immunité à la douleur": { icon: "game-icon-armor-upgrade", rankClass: "c-class" },
        "Grands sauts": { icon: "game-icon-jump-across", rankClass: "c-class" },
        "Endurance illimitée": { icon: "game-icon-battery-pack", rankClass: "b-class" },
        "Vision nocturne": { icon: "game-icon-semi-closed-eye", rankClass: "b-class" },
        "Amélioration des sens": { icon: "game-icon-human-ear", rankClass: "b-class" },
        "Bouclier": { icon: "game-icon-aura", rankClass: "a-class" },
        "Peau d'acier": { icon: "game-icon-metal-hand", rankClass: "a-class" },
        "Corps résistant aux températures extrêmes": { icon: "game-icon-frostfire", rankClass: "a-class" },
        "Vision à travers les objets/murs": { icon: "game-icon-crystal-eye", rankClass: "s-class" },
        "Oxygène illimitée": { icon: "game-icon-bubbles", rankClass: "s-class" },
        "Clonage": { icon: "game-icon-relationship-bounds", rankClass: "s-class" },
        "Vol": { icon: "game-icon-fluffy-wing", rankClass: "ten" },
        "Grande vitesse": { icon: "game-icon-fluffy-swirl", rankClass: "ten" },
        "Force surhumaine": { icon: "game-icon-mighty-force", rankClass: "ten" },
        "Barrière mentale": { icon: "game-icon-awareness", rankClass: "v-class" },
        "Force décuplée": { icon: "game-icon-strong", rankClass: "v-class" },
        "Immobilisation": { icon: "game-icon-crossed-chains", rankClass: "v-class" },
        "Peau de cristal": { icon: "game-icon-gems", rankClass: "v-class" }
    };

    // Function to add icons and tooltips with rank color applied via CSS variable
    function addIcons() {
        // Select all list items in both .field-mods and #field_id2 sections
        const userItems = document.querySelectorAll('.user_field.field-mods .profile_field_list li');

        userItems.forEach(item => {
            const itemText = item.textContent.trim();

            // Check if the icon is already added (by checking if the icon already exists)
            if (!item.querySelector('.item-icon') && itemsWithIcons[itemText]) {
                // Get the rank class for this item
                const rankClass = itemsWithIcons[itemText].rankClass;
                const iconClass = itemsWithIcons[itemText].icon;

                // Create the icon element
                const icon = document.createElement('i');
                icon.classList.add('game-icon');  // Add the base 'game-icon' class
                icon.classList.add(iconClass);  // Add the specific icon class from the list

                // Create the tooltip element
                const tooltip = document.createElement('span');
                tooltip.classList.add('tooltip');
                tooltip.textContent = itemText;  // Tooltip text is the list item text

                // Get the color from the CSS variable corresponding to the rank class
                const rankColor = getComputedStyle(document.documentElement).getPropertyValue(`--${rankClass}`).trim();

                // Apply the rank color to the CSS variable --modrank for each item
                item.style.setProperty('--modrank', rankColor);

                // Append the icon and tooltip to the item
                item.innerHTML = '';  // Clear any existing content
                item.appendChild(icon);
                item.appendChild(tooltip);
            }
        });
    }

    // Directly check if the elements exist after page load
    function checkAndAddIcons() {
        const modsElement = document.querySelector('.user_field.field-mods');
        const fieldId2Element = document.querySelector('.profile_field#field_id2');

        // If either section is found, add icons to both
        if (modsElement || fieldId2Element) {
            addIcons(); // Add icons if either section exists
        } else {
            // Optionally retry if neither is found (but minimize this)
            setTimeout(checkAndAddIcons, 100);  // Retry after 100ms (minimal delay)
        }
    }

    // Start by checking after the page loads
    checkAndAddIcons();

    // Use MutationObserver to observe changes to both sections
    const observer = new MutationObserver(mutations => {
        let needsIconUpdate = false;

        mutations.forEach(mutation => {
            if (mutation.type === 'childList') {
                const targetClass = mutation.target.className;
                if (targetClass.includes('field-mods') || mutation.target.id === 'field_id2') {
                    needsIconUpdate = true;  // Mark the need for an update if either section changes
                }
            }
        });

        if (needsIconUpdate) {
            addIcons();  // Add icons only when necessary
        }
    });

    // Observe the necessary parent elements, specifically targeting changes to .field-mods and #field_id2
    const targetNode = document.body; // Observe changes in the entire body
    observer.observe(targetNode, { childList: true, subtree: true });
});
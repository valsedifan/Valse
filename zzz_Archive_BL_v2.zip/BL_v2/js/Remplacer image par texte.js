// PLACEMENT : sur toutes les pages

$(function(){

  // BOUTON DE SUJET 
  
$('.newtopic_button').replaceWith("Nouveau"); // Ouvrir un nouveau sujet
$('.reply_button').replaceWith("Repondre"); // Répondre au sujet
  
$('.newpm_button img').replaceWith("Nouveau"); // Envoyer un nouveau MP
$('.replypm_button img').replaceWith("Repondre"); // Répondre au MP 
  
  // BOUTON EDITION DE MESSAGE
   $('.i_icon_quote').replaceWith("Citer"); // Bouton "citer"
   $('#i_icon_quote').replaceWith("Citer"); // Bouton "citer" dans les MP
   $('.i_icon_edit').replaceWith("Editer"); // Bouton "éditer"
   $('.i_icon_delete').replaceWith("Supprimer"); // Bouton "supprimer"
   $('#i_icon_delete').replaceWith("Supprimer"); // Bouton "supprimer" dans les MP et sondage
   $('.i_icon_ip').replaceWith("IP"); // Bouton "IP"
  
  
});
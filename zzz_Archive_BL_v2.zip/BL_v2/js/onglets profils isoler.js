jQuery(function () {

    // on indique la version du forum
    // attention de bien respecter les écritures ci-dessous
    // invision, phpbb2, phpbb3, punbb, Invision, ModernBB, AwesomeBB
    var versionForum = 'phpbb2',
        $chemin,
        $eltParent = '.postdetails.poster-profile';

    // On indique le chemin vers la balise qui contient les champs du profil
    switch(versionForum){
        // Si on est sur invision
        case 'invision':
            $chemin = ".post .postbody .user-info .infos-posteur";
            break;

        // Si on est sur phpbb2
        case 'phpbb2':
            $chemin = ".post .postdetails.poster-profile .infos-posteur";
            break;

        // Si on est sur punbb
        case 'punbb':
            $chemin = ".post .postbody .user-info .infos-posteur";
            break;

        // Si on est sur AwesomeBB
        case 'AwesomeBB':
            $chemin = ".post-wrap .post-body .post-aside .infos-posteur";
            $eltParent = ".post-aside";
            break;

        // Si on est sur phpbb3, ModernBB, Invision
        default:
            $chemin = ".post_profil .postinfobox .infos-posteur";
            break;
    };

    // Si la structure est différente de celle de base
    // indiquer le bon chemin et
    // décommenter (en supprimer // ) la ligne ci-dessous
    // chemin = "ton chemin";

    // On parcourt chaque champs des profils
    $( $chemin ).each(function( index ) {
        // On récupére le contenu html de ces champs
        var champs = $(this).find('.label > span:first-child').html() ;
 
        // On teste sur le champs correspond aux blocs qu'on veut isoler
        // pour info || signifie "ou"
if( champs == "Date d'inscription" || champs == "District"){
            // Je déplace le contenu dans le bloc
            $(this).parents($eltParent).find('.other').append(this);
 
        }
 
    });
});
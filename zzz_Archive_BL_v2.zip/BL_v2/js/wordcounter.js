var wordcount = false;
                 
$(function(){
  if(!$('#text_editor_textarea').length || !$.fn["sceditor"]) return;

  $(function(){

    var e= $('#text_editor_textarea').sceditor('instance');
    if(!e) return;

    var wordCounter = $('<div class="word-counter"></div>').insertAfter('.sceditor-container');

    var count = function(){
      var t = '';
      var val = e.val().length;

      if(val > 0){
        t = e.val().replace(/<(?:.|\n)*?>/gm, '');
        t = t.replace(/\[(?:.|\n)*?\]/gm, '');
        t = t.split(' ');
      }
     
      wordCounter.html('Nombre de mots : '+ t.length);
      wordcount = false
    };

    e.keyDown(function(){
      if(wordcount) return;
      wordcount = true;
      count()
    });

    count()

  })
});
$(document).ready(function () {
	
	const lottery = $('.postbody_msg img[src^="https://img.com/lot"]'); 
	
if (lottery.length === 0) {
    return;
  }

if ($('#lottery-styles').length === 0) {
    var css =
  '.dice.lottery {' +
    'position: relative;' +
    'padding: 10px;' +
    'margin: 20px auto;' +
    'width: 350px;' +
    'height: 437px;' +
  '}' +
  '.dice.lottery:before {' +
    'content: "";' +
    'position: absolute;' +
    'top: 0;' +
    'left: 0;' +
    'width: 100%;' +
    'height: 100%;' +
    'background: var(--gradient3);' +
    'z-index: -1;' +
    'opacity: 0.7;' +
  '}' +
  '.dice.lottery > .innerlot {' +
    'background: var(--transp7);' +
    'height: 100%;' +
    'padding: 50px 0;' +
    'display: flex;' +
    'flex-direction: column;' +
  '}' +
  '.dice.lottery h1 {' +
    'margin: 0;' +
    'text-align: center;' +
    'line-height: 100%;' +
    'font-size: 2.5em;' +
    'color: var(--co3);' +
    'text-shadow: -2px -2px 0 var(--co2), -3px -3px 0 var(--co1);' +
  '}' +
  '.dice.lottery .lot {' +
    'position: relative;' +
    'margin: 20px 30px;' +
    'height: 100%;' +
    'margin-bottom: 0;' +
    'cursor: grabbing;' +
  '}' +
  '.dice.lottery .lot > .innerscratch, .dice.lottery .lot > .scratch {' +
    'position: absolute;' +
    'top: 0;' +
    'left: 0;' +
    'border-radius: 5px;' +
    'width: 100%;' +
    'height: 100%;' +
    'display: grid;' +
    'place-items: center;' +
  '}' +
  '.dice.lottery .lot > .scratch {' +
    'background: var(--gradientcate);' +
    'transition: opacity .3s;' +
  '}' +
  '.dice.lottery .lot:hover .scratch, .dice.lottery .lot:focus .scratch, .dice.lottery .lot:active .scratch {' +
    'opacity: 0;' +
  '}' +
  '.dice.lottery .lot > .innerscratch {' +
    'padding: 20px;' +
    'border: 1px solid var(--co2);' +
    'background: var(--transp9);' +
  '};';
  

    $('<style id="lottery-styles" type="text/css">' + css + '</style>')
      .appendTo('head');}
	
var messages = {
1: 'rien, pleure',
2: '1 paquet de 5 cartes (regular, shiny ou  valentine au choix)',
3: '100 wons',
4: '50 wons',
5: 'rien, pleure',
6: '2 paquets de 5 cartes (regular, shiny ou  valentine au choix)',
7: '10 wons',
8: 'rien, pleure',
9: '250 wons',
10: 'le badge spécial de star',
11: 'rien, pleure',
12: '25 wons',
13: '1 000 wons',
14: 'rien, pleure',
15: '50 wons',
16: '1 paquet de 10 cartes (regular, shiny ou  valentine au choix)',
17: 'rien, pleure',
18: 'carte limitée au choix (toutes collections sorties)',
19: '500 wons',
20: 'rien, pleure',
21: '25 wons',
22: '1 paquet de 5 cartes (regular, shiny ou  valentine au choix)',
23: 'rien, pleure',
24: '100 wons',
25: '2 500 wons',
26: 'rien, pleure',
27: '50 wons',
28: 'le badge spécial de star',
29: '10 wons',
30: '250 wons',
31: 'rien, pleure',
32: 'carte limitée au choix (toutes collections sorties)',
33: '100 wons',
34: 'rien, pleure',
35: '25 wons',
36: '500 wons',
37: 'rien, pleure',
38: '2 paquets de 10 cartes (regular, shiny ou  valentine au choix)',
39: '50 wons',
40: 'rien, pleure',
41: '10 wons',
42: '1000 wons',
43: 'rien, pleure',
44: '250 wons',
45: '1 paquet de 10 cartes (regular, shiny ou  valentine au choix)',
46: 'rien, pleure',
47: '100 wons',
48: 'le badge spécial de star',
49: 'rien, pleure',
50: '5000 wons',
51: '1 paquet de 5 cartes (regular, shiny ou  valentine au choix)',
52: 'rien, pleure',
53: '50 wons',
54: '500 wons',
55: 'rien, pleure',
56: 'carte limitée au choix (toutes collections sorties)',
57: '2 paquets de 5 cartes (regular, shiny ou  valentine au choix)',
58: 'rien, pleure',
59: '100 wons',
60: '25 wons',
61: 'rien, pleure',
62: '1000 wons',
63: '250 wons',
64: 'rien, pleure',
65: '10000 wons, bravo notre milliardaire',
66: 'rien, pleure',
67: '1 paquet de 5 cartes',
68: '50 wons',
69: 'le badge spécial de star',
70: 'carte limitée au choix (toutes collections sorties)',
71: '2 paquets de 10 cartes (regular, shiny ou  valentine au choix)',
72: 'rien, pleure',
73: '100 wons',
74: 'multicompte gratuit sans rp, la belle vie, la dolce vita (1 fois par pseudo)',
75: 'rien, pleure',
76: '250 wons',
77: '1 paquet de 10 cartes (regular, shiny ou  valentine au choix)',
78: 'rien, pleure',
79: '500 wons',
80: 'rien, pleure',
81: '10 wons',
82: '10 wons',
83: 'rien, pleure',
84: '25 wons',
85: 'le badge spécial de star',
86: 'rien, pleure',
87: 'rien, pleure',
88: '1 paquet de 5 cartes (regular, shiny ou  valentine au choix)',
89: '100 wons',
90: 'rien, pleure',
91: '250 wons',
92: 'carte limitée au choix (toutes collections sorties)',
93: 'rien, pleure',
94: '500 wons',
95: '25 wons',
96: 'rien, pleure',
97: '2 paquets de 5 cartes (regular, shiny ou  valentine au choix)',
98: 'le badge spécial de star',
99: 'réservation de fc (1 par joueur.se)',
100: 'membre du mois, notre superstar de la loterie sur la pa (lot unique)'
};
	
	lottery.each(function () { 
		const src = $(this).attr("src"); 
		const match = src.match(/lot(\d+)\.png$/); 
		const number = match ? match[1] : null; 
		const text = messages[number] || "contacter le staff, y'a un problème"; 
		
		$(this).hide(); 
		
		$('<div class="dice lottery"><div class="innerlot"><h1>loterie bl<br>2026</h1><div class="lot"><div class="innerscratch"><div style="text-align:center"><t1>tu as gagné </t1><h3>' + text + '</h3></div></div><div class="scratch"><t1 style="text-transform:lowercase;color:var(--bw2);font-style:italic;">scratch here</t1></div></div></div></div>').insertBefore(this); }); 
	
});
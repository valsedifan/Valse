$(function () {
    const waitForSCEditor = setInterval(function () {
        const $toolbar = $('.sceditor-toolbar');
        if ($toolbar.length && $toolbar.find('.sceditor-group').length) {
            clearInterval(waitForSCEditor);

            const buttonGroups = [
                { name: 'couleurs', tags: ['c1', 'c2', 'c3', 'c4', 'c6', 'c5'] },
                { name: 'gras', tags: ['b1', 'b2', 'b4', 'b3'] },
                { name: 'italique', tags: ['i1', 'i2', 'i5', 'i3', 'i4'] },
                { name: 'sous-ligné', tags: ['u1', 'u2', 'u6', 'u3', 'u4', 'u7', 'u5'] },
                { name: 'fonds', tags: ['s1', 's2', 's3', 's4', 's6', 's5', 'datum', 'datum2', 'spoiler1'] },
                { name: 'titres', tags: ['t1', 't2', 't3', 't4', 't5', 't8', 't9', 'y', 'y2'] }
            ];

            var customGroupsHTML = '<span></span>';
            $.each(buttonGroups, function (_, group) {
                customGroupsHTML += '<div class="sceditor-group custom-group" data-group="' + (group.name || '') + '">';
                $.each(group.tags, function (_, tag) {
                    customGroupsHTML += '<a href="#" class="custom-button" data-tag="' + tag + '" title="<'+tag+'>"><' + tag + '>texte</' + tag + '></a>';
                });
                customGroupsHTML += '</div>';
            });
          
            $toolbar.append(customGroupsHTML);

            function insertTag(tag) {
                var $source = $(".sceditor-container textarea:visible");
                var $iframeBody = $(".sceditor-container iframe").contents().find("body");

                if ($source.length) {
                    // Source mode
                    var textarea = $source.get(0);
                    var start = textarea.selectionStart;
                    var end = textarea.selectionEnd;
                    var text = textarea.value;
                    textarea.value = text.substring(0, start) + '<' + tag + '>' + text.substring(start, end) + '</' + tag + '>' + text.substring(end);
                    textarea.selectionStart = textarea.selectionEnd = end + tag.length * 2 + 5;
                    textarea.focus();
                } else if ($iframeBody.length) {
                    var iframe = $(".sceditor-container iframe").get(0);
                    var selection = iframe.contentWindow.getSelection();
                    if (!selection.rangeCount) return;
                    var range = selection.getRangeAt(0);
                    var span = document.createElement("span");
                    span.innerHTML = '<' + tag + '>' + range.toString() + '</' + tag + '>';
                    range.deleteContents();
                    range.insertNode(span);
                }
            }

            $toolbar.on('click', '.custom-button', function (e) {
                e.preventDefault();
                insertTag($(this).data('tag'));
            });
        }
    }, 500);
});
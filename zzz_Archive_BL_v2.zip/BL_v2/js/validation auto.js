$(document).ready(function() {
	if (_userdata.user_level == 1) {
		$('#AdminValidation').load('/h55-validation-automatique-presa');
	}
});
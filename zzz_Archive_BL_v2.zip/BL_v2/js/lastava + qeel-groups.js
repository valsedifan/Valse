$(function () {
  try {
    $.get($('#newest_user a[href^=\'/u\']') [0].href, function (d) {
        (a = $('#user_avatar img', $(d))).length && $('#lastuser_avatar').html(a)
    })
  } catch(e) {}

  const gpajax = $('.gpajax'); // Target the container for AJAX content

    // Function to calculate percentage safely
    const calculatePercentage = (part, total) =>
        total > 0 ? Math.round((part / total) * 100) + "%" : "0%";

    // Function to safely parse numbers
    const parseNumber = (selector) => {
        const value = $(selector).text().trim();
        return Number(value.replace(/\D/g, '')) || 0; // Remove non-numeric and convert to number
    };

    $.ajax({
        url: "/groups",
        type: 'GET',
        success: function (data) {
            const groupesdata = $(data).find('.group_list'); // Changed class to .group_list
            gpajax.html(groupesdata); // Populate .gpajax with the fetched data
        }
    }).done(function () {
	const pnj = Number($("#nb-users-g8").text().replace(/\D/g, '')) || 0;

        // Dynamically extract values from the `.group_list` div
        const categories = {
            total: "#nb-users-g7", // Total members
            ten: "#nb-users-g9",
            s: "#nb-users-g10",
            a: "#nb-users-g11",
            b: "#nb-users-g12",
            c: "#nb-users-g13",
            t: "#nb-users-g14",
            x: "#nb-users-g15",
            v: "#nb-users-g16",
            h: "#nb-users-g17"
        };

        const groups = {
            ego: "#nb-users-g3",
            savior: "#nb-users-g4",
            messy: "#nb-users-g5"
        };

        // Total members excluding `pnj`
        const totalMembers = parseNumber(categories.total) - pnj;

        // Fill #nbTotalMembre with the total number of members
        $('#nbTotalMembre').text(totalMembers);

        // Update each category dynamically
        Object.entries(categories).forEach(([key, selector]) => {
            if (key !== "total") {
                const rawValue = parseNumber(selector);
                const adjustedValue = rawValue - pnj; // Adjust for `pnj`
                $(`#nb${key.charAt(0).toUpperCase() + key.slice(1)}`).text(adjustedValue); // Update count
            }
        });

        // Update groups (ego, savior, messy) bar widths only
        const groupTotal = Object.values(groups).reduce((sum, selector) => {
            return sum + parseNumber(selector);
        }, 0);

        Object.entries(groups).forEach(([key, selector], index) => {
            const count = parseNumber(selector);
            const percent = calculatePercentage(count, groupTotal);
            $(`#nbGroup${index + 1}`).css("width", percent); // Update width
        });
    });
});
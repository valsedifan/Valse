$(document).ready(function () {
	
	if (!window.location.href.includes("/memberlist"))
        return;

    // === SETTINGS ===
    var membersPerPage = 15; // FA setting
    var itemsPerPageDefault = 15; // items per page for Isotope
    var memberList = '.userlist-plus'; // wrapper around member blocks
    var itemSelector = '.userlist_profil-plus'; // member block
    var pseudoMembre = '.userlist_pseudo-plus'; // pseudo selector
    var jsonContainers = {
        "2": "userlist_infos",
 		"8": "userlist_infos",
        "10": "userlist_infos",
        "18": "userlist_infos",
        "-10": "userlist_infos",
        "-9": "userlist_infos",
        "4": "userlist_infos"
    };

    var allMembers = document.createDocumentFragment();

    // clear grid while loading
    $(memberList)
        .empty()
        .append('<div class="ldm_chargement">Chargement...</div>');

    // === LOAD ALL MEMBERS VIA AJAX ===
    loadAllMembers(1);

    function loadAllMembers(page) {
        var pageUrl = '/memberlist?start=' + ((page - 1) * membersPerPage);
		console.log(pageUrl);

        $.ajax({
            url: pageUrl,
            success: function (data) {
                var newMembers = $(data).find(memberList + ' ' + itemSelector);
                console.log('Page', page, 'found members:', newMembers.length);

                if (!newMembers.length) {
                    displayMembers();
                    return;
                }

                newMembers.each(function () {
                    var $member = $(this);

                    // Add data-inscription
                    var idMembre = $member.find(pseudoMembre)
                        .attr('href')
                        .replace(/[^0-9]/g, '');
                    $member.attr('data-inscription', idMembre);
                    console.log('Member ID:', idMembre);

                    // JSON fields
                    var jsonBlock = $member.find('.user-json')[0];
                    if (jsonBlock) {
                        try {
                            var data = JSON.parse(jsonBlock.textContent.trim());
                            console.log('JSON data for member:', data);

                            Object.entries(data).forEach(([key, field]) => {
                                if (!field || !field.label) return;
                                var containerClass = jsonContainers[key];
                                if (!containerClass) return;

                                var container = $member.find('.' + containerClass)[0];
                                if (!container) {
                                    container = document.createElement('div');
                                    container.className = containerClass;
                                    $member.append(container);
                                }

                                var wrapper = document.createElement('div');
                                wrapper.className = 'info_field' +
                                    field.label.replace(/\s+/g, '-').toLowerCase();

                                var label = document.createElement('label');
                                label.textContent = field.label;

                                var span = document.createElement('span');
                                span.textContent = field.content;

                                wrapper.appendChild(label);
                                wrapper.appendChild(span);
                                container.appendChild(wrapper);

                                console.log('Added JSON field:', field.label, field.content);
                            });
                        } catch (e) {
                            console.error('JSON parse error:', e, jsonBlock.textContent);
                        }
                    }

                    // Group class
                    var groupSpan = $member.find('a.userlist_pseudo-plus span[class^="group-"]')[0];
                    var groupClass = 'group-none'; // default if no group
                    if (groupSpan) {
                        groupClass = groupSpan.className
                            .split(' ')
                            .find(c => c.startsWith('group-')) || 'group-none';
                    }
                    $member.addClass(groupClass);
                    console.log('Added group class:', groupClass);

                    // Append member to fragment
                    allMembers.appendChild($member[0]);
                });

                // Decide whether to load next page or finish
                if (newMembers.length < membersPerPage) {
                    console.log('All members loaded, total:', $(allMembers).children().length);
                    displayMembers();
                } else {
                    loadAllMembers(page + 1);
                }
            },
            error: function () {
                console.error("Failed to load page " + page);
            }
        });
    }

    // === INITIALIZE ISOTOPE ===
    function displayMembers() {
        // Initialize Isotope
		var $grid = $(memberList)
			.empty()
			.append(allMembers)
			.isotope({
				itemSelector: itemSelector,
				getSortData: {
					pseudo: function(itemElem) {
						return $(itemElem).find('.userlist_pseudo-plus').text().trim().toLowerCase();
					},
					fc: function(itemElem) {
						return $(itemElem).find('.userlist_infos-user .info_faceclaim span').text().trim().toLowerCase() || '';
					},
					inscription: '[data-inscription] parseInt',
					derco: '[data-derco] parseInt'
				},
				sortBy: 'original-order',
				sortAscending: {
					pseudo: true,
					fc: true,
					inscription: false, // FA date usually descending by default
					derco: false
				}
			});

		$('.sort-by-button-group').on('click', 'button', function() {
			var sortBy = $(this).attr('data-sort-by');
			sorting = sortBy; 
			order = (sortBy === 'original-order') ? false : true;

			$grid.isotope({ 
				sortBy: sortBy,
				sortAscending: order
			});

			setPagination();
			goToPage(1);

			$(this).siblings().removeClass('is-checked');
			$(this).addClass('is-checked');
		});

		// Toggle ascending/descending
		$('.croiss-group').on('click', 'button', function() {
			order = $(this).attr('data-order') === 'true';

			$grid.isotope({
				sortBy: sorting,
				sortAscending: order
			});

			setPagination();
			goToPage(1);

			$(this).siblings().removeClass('is-checked');
			$(this).addClass('is-checked');
		});

        var responsiveIsotope = [
            [480, 3],
            [720, 6]
        ];

        var itemsPerPage = defineItemsPerPage();
        var currentNumberPages = 1;
        var currentPage = 1;
        var currentFilter = '*';
        var pageAttribute = 'data-page';
        var pagerClass = 'isotope-pager';
        var buttonFilters = {};
		var searchPseudoRegex;
        var searchFCRegex;

        // === PAGINATION FUNCTIONS ===
        function defineItemsPerPage() {
            var pages = itemsPerPageDefault;
            for (var i = 0; i < responsiveIsotope.length; i++) {
                if ($(window).width() <= responsiveIsotope[i][0]) {
                    pages = responsiveIsotope[i][1];
                    break;
                }
            }
            return pages;
        }

        function getFilterSelector() {
            return currentFilter != '*' ? currentFilter : '';
        }

        function changeFilter(selector, pages) {
            $grid.isotope({
                filter: function () {
					var $this = $(this);

					var searchPseudo = searchPseudoRegex
						? $this.find(pseudoMembre).text().match(searchPseudoRegex)
						: true;

					// faceclaim search
					var searchFC = searchFCRegex
						? $this.find('.userlist_infos-user .info_faceclaim span').text().match(searchFCRegex)
						: true;

					var buttonResult = selector ? $this.is(selector) : true;
					var pageResult = pages ? $this.is(pages) : true;

					return searchPseudo && searchFC && buttonResult && pageResult;
				}	
            });
        }

        function goToPage(n) {
            currentPage = n;
            var selector = getFilterSelector();
            var pages = `[${pageAttribute}="${currentPage}"]`;
            changeFilter(selector, pages);
        }

        function setPagination() {
            var items = $grid.children(getFilterSelector());
            var item = 1, page = 1;

            items.each(function () {
                if (item > itemsPerPage) {
                    page++;
                    item = 1;
                }
                $(this).attr(pageAttribute, page);
                item++;
            });
            currentNumberPages = page;

            var $pager = $('.' + pagerClass).length ? $('.' + pagerClass) : $('<div class="' + pagerClass + '"></div>');
            $pager.empty();
            if (currentNumberPages > 1) {
                for (var i = 1; i <= currentNumberPages; i++) {
                    $('<button class="button" ' + pageAttribute + '="' + i + '">' + i + '</button>')
                        .click(function () {
                            goToPage($(this).attr(pageAttribute));
                        })
                        .appendTo($pager);
                }
            }
            $grid.after($pager);
        }

        setPagination();
        goToPage(1);

        // === FILTER BUTTONS ===
        $('.filters').on('click', '.button', function () {
			var $this = $(this);
			var $group = $this.closest('.button-group');
			var filterGroup = $group.attr('data-filter-group');

			// Update the filter for this group
			buttonFilters[filterGroup] = $this.attr('data-filter');
			currentFilter = Object.values(buttonFilters).join('');

			// Update button classes
			$group.find('.button').removeClass('is-checked');
			$this.addClass('is-checked');

			// Apply filter
			setPagination();
			goToPage(1);
		});

        // === SEARCH ===
        $('.quicksearch_pseudo').keyup(debounce(function () {
            var val = $(this).val();
            searchPseudoRegex = val ? new RegExp(val, 'gi') : null;
            setPagination();
            goToPage(1);
        }));
		
		$('.quicksearch_fc').keyup(debounce(function () {
            var val = $(this).val();
            searchFCRegex = val ? new RegExp(val, 'gi') : null;
            setPagination();
            goToPage(1);
        }));


        // === RESIZE ===
        $(window).resize(function () {
            itemsPerPage = defineItemsPerPage();
            setPagination();
            goToPage(1);
        });

        function debounce(fn, threshold) {
            var timeout;
            threshold = threshold || 100;
            return function () {
                clearTimeout(timeout);
                var args = arguments, _this = this;
                timeout = setTimeout(function () {
                    fn.apply(_this, args);
                }, threshold);
            }
        }
    }

});
$(document).ready(function() {
  var pagination = $("span.pagination");
  pagination.each(function(){

    $(this).find('.pag-img:has(img[alt="Précédent"])').html('<i class="cp cp-chevron-left"></i>');
    
    $(this).find('.pag-img:has(img[alt="Suivant"])').html('<i class="cp cp-chevron-right"></i>');
  });
});
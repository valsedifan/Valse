/**
 * Script de personnalisation des champs de contact dans les messages
 * Emplacement : sur les sujets
 * @author 'Christa Lostmindy
 */

document.addEventListener('DOMContentLoaded', () => {

    /* Vos réglages se feront ici */
    const SELECTEUR_CHAMPS_CONTACT = '.profil_contact img'; /* sélecteur CSS qui permet d'identifier l'image d'un champ de contact */  
    const LISTE_CHAMPS_CONTACT = [ /* Liste des champs de contact à modifier, suivez l'exemple et faites attention à l'emplacement des virgules et crochets */
        {
            urlImg : 'icon_user_profile.png',
            replacementCode : '<i class="cp cp-diamond"></i>',
            title : 'voir le profil'
        },
        {
            urlImg : 'icon_contact_pm.png',
            replacementCode : '<i class="cp cp-envelope"></i>',
            title : 'envoyer un message privé'
        },
        {
            urlImg : 'icon_contact_www.png',
            replacementCode : '<i class="cp cp-id-card"></i>',
            title : 'accéder à la présentation'
        },
        {
            urlImg : 'carnetdebord.png',
            replacementCode : '<i class="cp cp-bookmark"></i>',
            title : 'accéder au carnet de bord'
        },
        {   urlImg : 'playlist.png',
            replacementCode : '<i class="cp cp-music-note"></i>',
            title : 'accéder à la playlist'
        },
         {
            urlImg : 'moodboard.png',
            replacementCode : '<i class="cp cp-image"></i>',
            title : 'accéder au moodboard'
        },
         {
            urlImg : 'instagram.png',
            replacementCode : '<i class="cp cp-instagram"></i>',
            title : "accéder à l'instagram"
         }
    ];

    /* Le script */
    let mapChampsParUrl = {};
    LISTE_CHAMPS_CONTACT.forEach( champ => { mapChampsParUrl[champ.urlImg] = champ});

    document.querySelectorAll(SELECTEUR_CHAMPS_CONTACT)?.forEach(image => {
        let definitionContact = mapChampsParUrl[image.src.substring(image.src.lastIndexOf('/') + 1)];
        if(definitionContact) {
            if (definitionContact.title?.trim().length) image.parentElement.setAttribute('title', definitionContact.title);
            if (definitionContact.replacementCode?.trim().length) image.parentElement.innerHTML = definitionContact.replacementCode;
        }
    });

});
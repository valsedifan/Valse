$(document).ready(function() {
	$('#tcg-tirage').load('/h3-tcg-tirages');
	$('#tierlisthtml').load('/h14-tier-list');
	$('#boutique').load('/h43-boutique');
	$('#accomplissements').load('/h44-culture-heroique-accomplissements');
	$('#culturehero').load('/h45-culture-heroique-culture');
	$('#stval26_dice').load('/h54-stval26_dice');
	if (_userdata.user_level == 1) {
		$('#AdminValidation').load('/h55-validation-automatique-presa').css('display', 'block');
	}
    if (_userdata.user_level == 1) {
		$('.AdminOnly').css('display','block');
	}
	$('.instaReactions').load('/h56-instagram-actions');
	$('#ao3_listing').load('/h58-ao3-table-of-content');
	$('#sphh_listing').load('/h61-listing-super-paradisehero-haven');
});
$(document).ready(function() {
const victory = $('.postbody_msg img[src*="6xr8.png"]');
const defeat = $('.postbody_msg img[src*="h80d.png"]');
  
victory.each(function(){
  $(this).css("display","none");
  $('<div class="dice victory">victory</div>').insertBefore(this);
});
  
defeat.each(function(){
  $(this).css("display","none");
  $('<div class="dice defeat">defeat</div>').insertBefore(this);
});
});
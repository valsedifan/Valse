// [ validation RPG ] par .1019 & Monomer
//
// Un script pour valider automatiquement des personnages
//
// Version 1.0 :
//
// --- Ajoute un bouton de validation sur les fiches
// --- Permet de poster un message de validation
// --- Permet d'éditer des bottins et de les trier dans un ordre alphabétique
// --- Permet d'ajouter un groupe à la personne validée
// --- Permet d'ajouter un badge (une récompense) à la personne validée
// --- Permet de déplacer la fiche de catégorie
//
// Merci de ne pas retirer ni les commentaires ni les crédits. Ils sont utiles
// pour vous, les prochains développeurs qui passeront après vous et également
// pour pouvoir se rappeler de mon pseudo (.1019) en cas de besoin.
//
// Merci de ne contacter que .1019 dans le cadre de ce script. :)

// Pour créer le bouton

$('document').ready(function() {
    let url = window.location.href;
    if(url.includes('/t') &&
	// ID de la catégorie où il y a les fiches en cours
	document.querySelector('.navigation_links a[href*="/f129-"]') && 
	// Si Admin
	_userdata["user_level"] == 1) {
        // On crée le bouton
        let refreshButton = $(`<br/><center><button id="validationBtn" type="submit" name="post" onClick="validationFiche()">Valider la présentation</button></center>`);
        // --- MOD --- Il faut mettre ici l'ID du titre du sujet ou du bloc où on veut voir le bouton de validation
        $("#AdminValide").append(refreshButton);
    }
});

function validationFiche() {
    var grpName = null;
	var rankName = null;

    // Liste des groupes avec leurs ID en tant que clefs
    // --- MOD --- Il faut mettre ici l'ID du groupe et le nom du groupe
    var listGrp = {
        "3" : "ego",
        "4" : "savior",
        "5" : "messy"
    };

    var listRank = {
        "9" : "ten",
        "10" : "s-class",
        "11" : "a-class",
        "12" : "b-class",
        "13" : "c-class",
        "14" : "t-class",
        "15" : "x-class",
        "16" : "v-class",
        "17" : "h-class",
    };

    // On récupère le tid
    var tid = $('a[href^="/admin/?part=admin&tid="]').attr("href").split("&")[1];
    tid = tid.split("=")[1];

    // On récupère l'ID du topic
    var t = $('input[name="t"]')[0].value;

    // On vérifie s'il y a plusieurs pages & on assigne l'URL de la fiche
    var multiplePages = $('a[href="javascript:Pagination();"]').length >= 1;
    var ficheUrl = window.location.href;   if(multiplePages) {
        ficheUrl = $('a[href="javascript:Pagination();"]')[0].nextElementSibling.href;
        // Si on est sur la première page on dit qu'il n'y a pas plusieurs pages
        if(ficheUrl == undefined) {
            multiplePages = false;
        }
    }

    // On vérifie s'il y a plusieurs pages, si c'est le cas on va sur la première page
    if(multiplePages) {
        $.get(ficheUrl, function(res) {
            // On récupère les updates à ajouter dans la fiche en validation
            grpName = $(res).find('.presa_groupe')[0].innerText;
			rankName = $(res).find('.presa_rank')[0].innerText;
        });
    } else {
        // On récupère les updates à ajouter dans la fiche en validation
        // Récupération du champ du bottin (dans un ID)
        grpName = $(res).find('.presa_groupe')[0].innerText;
		rankName = $(res).find('.presa_rank')[0].innerText;
    }

    // Id des catégories des fiches validées
    // --- MOD --- Il faut changer ici le f avec l'ID de la catégorie où les fiches sont en cours
    // --- MOD --- Il faut changer le newF avec l'ID de la catégorie où les fiches sont validées
    var f = '3';
    var newF = '133';

    posterMessage(t, grpName, rankName, listRank);
    addGroup(multiplePages, ficheUrl, listGrp, listRank, tid);
    moveSubject(f, newF, t, tid);
}

// ------------------------------- posterMessage()
//
// Fonction permettant d'envoyer un message personnalisé de validation.
//
// t [Type : String] : attend l'ID du topic
function posterMessage(t, grpName) {
    // On récupère la remarque personnalisée
    let message = prompt("ENVOI DU MESSAGE DE VALIDATION :\r\n\r\nAjoutez votre remarque personnalisée au message de validation :");

    // On crée le message et on intègre la remarque personnalisée
    //
    // --- MOD --- ici il faut mettre le message de validation
    if(message) {
        if(grpName == "Vampire") {
            message =
                "<div class=\"cadre-admin\"><div class=\"bloc\"><div class=\"title\" style=\"color:var(--violet);text-align:center;\">Tu es valid\u00E9<\/div>\r\n" + message + "</div></div></div>";
    }

    let body = {
        mode: 'reply',
        message,
        t,
        subject: "",
        confirm: 1
    };


    new Fetcher("/post", {
        method: 'POST'
    }, body).then(function(res) {
        return res.text();
    }).then(function(dom) {
        // --- MOD --- si vous avez modifié l'affichage de message d'erreur ça risque d'être compliqué
        let domMsg = $(dom).find('.forumline')[1];
        domMsg = $(domMsg).find('.gen')[0];
        // Pour retirer les boutons "continuer" etc
        while(domMsg.lastElementChild) {
            domMsg.removeChild(domMsg.lastElementChild);
        };
        domMsg = domMsg.innerText;
        alert("ENVOI DU MESSAGE DE VALIDATION :\r\n\r\n" + domMsg);
    }).catch(function(e) {
        alert("ENVOI DU MESSAGE DE VALIDATION :\r\n\r\nUne erreur a été rencontrée lors de l'envoi du message de validation : " + e);
    });
	}	
}
	
	// ------------------------------- addGroup()
//
// Fonction permettant d'ajouter la personne qui poste la fiche à un groupe choisi.
//
// multiplePages [Type : boolean] : attend true s'il y a plusieurs pages à la fiche de présentation
// ficheUrl [Type : String] : attend l'URL de la fiche de présentation
// listGrp [Type : Object] : attend une liste de groupes ( [key - id du groupe] : [value - nom du groupe] )
// tid [Type : String] : attend le tid
function addGroup(multiplePages, ficheUrl, listGrp, tid) {
    // On récupère les données pour ajouter au groupe
    var username = null;
    var g = null;
    var gText = null;

    // g est initilalisé avec un select option
    if(multiplePages) {
        $.get(ficheUrl, function(res) {
            // --- MOD ---
            username = $(res).find('.post-username a')[0].innerText;
            g = $(res).find('#fiche-grp')[0].value;
            gText = $(res).find("#fiche-grp option:selected").text();
        });
    } else {
        // --- MOD ---
        username = $('.post-username a')[0].innerText;
        g = $('#fiche-grp')[0].value;
        gText = $("#fiche-grp option:selected").text();
    }

    // On vérifie que l'ID correspond bien au groupe choisi sur la fiche (au cas où des petits malins changent ça)
    if(!(listGrp[g].toLowerCase() == gText.toLowerCase())) {
        if(!confirm("AJOUT AU GROUPE :\r\n\r\nAttention : vous allez ajouter ce personnage au groupe : " + listGrp[g] + ". Est-ce bien correct ?")) {
            alert("AJOUT AU GROUPE :\r\n\r\nLe groupe n'a pas été ajouté à l'utilisateur, merci de le faire manuellement.");
            return;
        } else {
            alert("AJOUT AU GROUPE :\r\n\r\nLe groupe " + listGrp[g] + " va être ajouté à " + username + ", veuillez patienter.");
        }
    }

    let body = {
        username,
        add: 1,
        g,
        tid
    };
	
    new Fetcher("/g" + g + "-", {
        method: 'POST'
    }, body).then(function(res) {
        return res.text();
    }).then(function(dom) {
        alert("AJOUT AU GROUPE :\r\n\r\nVous avez ajouté " + username + " avec succès au groupe \"" + listGrp[g] + "\".");
    }).catch(function(e) {
        alert("AJOUT AU GROUPE :\r\n\r\nUne erreur a été rencontrée : " + e);
    });
}
	
function addRank(multiplePages, ficheUrl, listRank, tid) {
    // On récupère les données pour ajouter au groupe
    var username = null;
    var r = null;
    var rText = null;

    // g est initilalisé avec un select option
    if(multiplePages) {
        $.get(ficheUrl, function(res) {
            // --- MOD ---
            username = $(res).find('.post-username a')[0].innerText;
            r = $(res).find('#fiche-grp')[0].value;
            rText = $(res).find("#fiche-grp option:selected").text();
        });
    } else {
        // --- MOD ---
        username = $('.post-username a')[0].innerText;
        r = $('#fiche-grp')[0].value;
        rText = $("#fiche-grp option:selected").text();
    }

    // On vérifie que l'ID correspond bien au groupe choisi sur la fiche (au cas où des petits malins changent ça)
    if(!(listRank[r].toLowerCase() == rText.toLowerCase())) {
        if(!confirm("AJOUT AU GROUPE :\r\n\r\nAttention : vous allez ajouter ce personnage au groupe : " + listRank[r] + ". Est-ce bien correct ?")) {
            alert("AJOUT AU GROUPE :\r\n\r\nLe groupe n'a pas été ajouté à l'utilisateur, merci de le faire manuellement.");
            return;
        } else {
            alert("AJOUT AU GROUPE :\r\n\r\nLe groupe " + listRank[r] + " va être ajouté à " + username + ", veuillez patienter.");
        }
    }

    let body = {
        username,
        add: 1,
        r,
        tid
    };    
		new Fetcher("/g" + r + "-", {
        method: 'POST'
    }, body).then(function(res) {
        return res.text();
    }).then(function(dom) {
        alert("AJOUT AU GROUPE :\r\n\r\nVous avez ajouté " + username + " avec succès au groupe \"" + listRank[r] + "\".");
    }).catch(function(e) {
        alert("AJOUT AU GROUPE :\r\n\r\nUne erreur a été rencontrée : " + e);
    });
}
	
	// ------------------------------- moveSubject()
//
// Fonction permettant de déplacer un sujet dans une autre catégorie.
//
// f [Type : String] : attend l'id de catégorie des fiches validées
// t [Type : String] : attend l'ID du topic
// tid [Type : String] : attend le tid
function moveSubject(f, newF, t, tid) {
    let body = {
        mode: 'move',
        new_forum: "f" + newF,
        f,
        t,
        confirm: 1,
        tid
    };

    new Fetcher("/modcp?tid=" + tid, {
        method: 'POST'
    }, body).then(function(res) {
        return res.text();
    }).then(function(dom) {
        alert("DEPLACEMENT DU SUJET :\r\n\r\nVous avez déplacé la fiche dans la catégorie des fiches validées.");
    }).catch(function(e) {
        alert("DEPLACEMENT DU SUJET :\r\n\r\nUne erreur a été rencontrée lors du déplacement de la fiche : " + e);
    });
}
	
	/* ------------------- */
/* FETCHER par MONOMER */
/* ------------------- */
// Permet de faire les requêtes Fetch sans que je me prenne la tête

function Fetcher(url, options, body) {
    /* new fetch facade with defaults */
    if(window.fetch) {
        return fetch(url, this.fetchOptions(options, body));
    } else {
        // to do, fallback with straight ajax? with axios?
        return new Error("Fetch API not found.");
    }
}

Fetcher.prototype.fetchOptions = function(options, body) {
    /* setup default headers and parse of body for FA */
    const update = {
        ...options
    };
    update.headers = {
        ...update.headers,
        'Content-Type': 'application/x-www-form-urlencoded'
    };
    update.body = this.bodyData(body);
    return update;
};


Fetcher.prototype.toFormData = function(obj) {
    var form_data = new FormData();

    for(var key in obj) {
        form_data.append(key, obj[key]);
    }
    return form_data;
};

Fetcher.prototype.encodeFormData = function(data) {
    return [...data.entries()].map(x => `${encodeURIComponent(x[0])}=${encodeURIComponent(x[1])}`).join('&');
};

Fetcher.prototype.bodyData = function(obj) {
    // compatible data for FA with fetch
    return this.encodeFormData(this.toFormData(obj));
};

// Fonction pour trier en ordre alphabétique
function asc_sort(a, b){
    return ($(b).text()) < ($(a).text()) ? 1 : -1;
}
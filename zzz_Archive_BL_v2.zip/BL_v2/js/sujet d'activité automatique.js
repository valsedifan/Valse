function buildActiMessage(username, maj) {
    return `
        <div class="shortprofile"><center><h2><y2 style="text-transform:uppercase;">${username}</y2></h2><s2>${maj}</s2></center></div>
    `;
}

function postActiDirect(maj) {
  var username = _userdata.username;
  var maj = "version 22";

  var form = document.createElement("form");
  form.action = "/posting.forum";
  form.method = "post";
  form.style.display = "none";

  function addField(name, value, tag) {
    var el;

    if (tag === "textarea") {
      el = document.createElement("textarea");
    } else {
      el = document.createElement("input");
      el.type = "hidden";
    }

    el.name = name;
    el.value = value;
    form.appendChild(el);
  }

  addField("subject", username);
  addField("message", buildActiMessage(username, maj), "textarea");
  addField("mode", "newtopic");
  addField("f", "166");
  addField("topictype", "0");
  addField("post", "Poster");

  document.body.appendChild(form);

  if (form.elements["subject"]) {
    form.elements["subject"].value = username;
  }

  console.log("Submitting activity topic:", {
    subject: form.elements["subject"] ? form.elements["subject"].value : "",
    maj: maj,
    message: form.elements["message"] ? form.elements["message"].value : ""
  });

  form.submit();
}

$(document).on("click", "#open-activite-link", function(e) {
  e.preventDefault();
  postActiDirect();
});
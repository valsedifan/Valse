/* Script pour sauvegarder un message en cours de rédaction */
 
window.localStorage&&localStorage.getItem("br-target")&&(function(){$("meta[http-equiv='refresh'][content]:first").length&&function(){var a=JSON.parse(localStorage.getItem("br-data")),b=localStorage.getItem("br-target"),c;if(-1!=(c=$.inArray(b,a))){a.splice(c,1),localStorage.setItem("br-data",JSON.stringify(a))}localStorage.removeItem(b)}();localStorage.removeItem("br-target");})();
 
window.localStorage&&$(function(){$(function(){if($("#text_editor_textarea").length==0)return;var a=$(document.post.mode).val(),d=$("#text_editor_textarea").sceditor("instance"),f,e,g=function(){localStorage.setItem(a,d.val());e=0},b=JSON.parse(localStorage.getItem("br-data"))||[],c;switch(a){case "editpost":return;case "reply":a+=$(document.post.t).val();break;case "newtopic":a+=$(document.post.f).val()}a=_userdata["user_id"]+a;-1!=(c=$.inArray(a,b))&&b.splice(c,1);if(20<b.length){for(c=b.length-1;0<=c;c--)if(/^\s*$/.test(localStorage.getItem(b[c])||
""))localStorage.removeItem(b[c]),b.splice(c,1);20<b.length&&(localStorage.removeItem(b[0]),b.splice(0,1))}b.push(a);localStorage.setItem("br-data",JSON.stringify(b));$(document.post).submit(function(){localStorage.setItem("br-target",a)});!d.val()&&(f=localStorage.getItem(a))&&d.val(f);d.keyUp(function(){e||(e=setTimeout(g,3E3))})})});
 
/* Script pour la redirection immédiate après la publication d'un sujet ou d'un message */
 
$("meta[http-equiv='refresh'][content]:first").each(function(){window.location.href=$(this).attr("content").replace(/^.*;url=/,"")});